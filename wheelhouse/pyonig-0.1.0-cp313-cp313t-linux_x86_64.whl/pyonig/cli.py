#!/usr/bin/env python3
"""CLI utility for syntax highlighting with pyonig."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import pyonig
from pyonig.colorize import Colorize, rgb_to_ansi


# Language to scope mapping
LANG_TO_SCOPE = {
    "json": "source.json",
    "yaml": "source.yaml",
    "yml": "source.yaml",
    "toml": "source.toml",
    "sh": "source.shell",
    "bash": "source.shell",
    "shell": "source.shell",
    "md": "text.html.markdown",
    "markdown": "text.html.markdown",
    "html": "text.html.basic",
    "htm": "text.html.basic",
    "log": "text.log",
}


def detect_language(filename: str | None) -> str | None:
    """Detect language from filename extension."""
    if not filename:
        return None
    
    ext = Path(filename).suffix.lstrip('.')
    return LANG_TO_SCOPE.get(ext.lower())


def render_to_ansi(colorized: list[list], colors: int = 256) -> str:
    """Convert colorized output to ANSI escape sequences.
    
    Args:
        colorized: Output from Colorize.render()
        colors: Number of terminal colors (8, 16, or 256)
    
    Returns:
        String with ANSI color codes
    """
    lines = []
    for line_parts in colorized:
        line = ""
        for part in line_parts:
            text = part.chars
            if part.color:
                # Convert RGB to ANSI
                r, g, b = part.color
                ansi_color = rgb_to_ansi(r, g, b, colors)
                line += f"\033[38;5;{ansi_color}m{text}\033[0m"
            else:
                line += text
        lines.append(line.rstrip('\n'))
    return '\n'.join(lines)


def main() -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Syntax highlight files using pyonig and TextMate grammars",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Highlight a JSON file
  pyonig file.json
  
  # Highlight from stdin
  cat file.yaml | pyonig --language yaml
  
  # Use a specific theme
  pyonig --theme terminal_colors file.py
  
  # Override language detection
  pyonig --language json file.txt
  
  # Specify terminal color support
  pyonig --colors 256 file.json
  
Supported languages:
  json, yaml, shell/bash, markdown, html, log
        """,
    )
    
    parser.add_argument(
        "file",
        nargs="?",
        help="File to highlight (reads from stdin if not provided)",
    )
    
    parser.add_argument(
        "-l", "--language",
        help="Language/scope to use (overrides auto-detection)",
    )
    
    parser.add_argument(
        "-t", "--theme",
        default="dark_vs",
        help="Theme name (without .json extension) or path to theme file (default: dark_vs)",
    )
    
    parser.add_argument(
        "-c", "--colors",
        type=int,
        choices=[8, 16, 256],
        default=256,
        help="Number of terminal colors to use (default: 256)",
    )
    
    parser.add_argument(
        "--list-languages",
        action="store_true",
        help="List supported languages and exit",
    )
    
    parser.add_argument(
        "--version",
        action="version",
        version=f"pyonig {pyonig.__version__} (oniguruma {pyonig.__onig_version__})",
    )
    
    args = parser.parse_args()
    
    if args.list_languages:
        print("Supported languages (extension -> scope):")
        for ext, scope in sorted(LANG_TO_SCOPE.items()):
            print(f"  {ext:10} -> {scope}")
        return 0
    
    # Read input
    if args.file:
        try:
            with open(args.file) as f:
                text = f.read()
            filename = args.file
        except FileNotFoundError:
            print(f"Error: File not found: {args.file}", file=sys.stderr)
            return 1
        except Exception as e:
            print(f"Error reading file: {e}", file=sys.stderr)
            return 1
    else:
        # Read from stdin
        text = sys.stdin.read()
        filename = None
    
    # Determine language
    if args.language:
        # Manual override
        if args.language in LANG_TO_SCOPE:
            language = LANG_TO_SCOPE[args.language]
        else:
            # Assume it's a scope name
            language = args.language
    else:
        # Auto-detect from filename
        language = detect_language(filename)
        if not language:
            print("Warning: Could not detect language. Use --language to specify.", file=sys.stderr)
            print(text)
            return 0
    
    # Load theme
    if args.theme.endswith('.json'):
        theme_path = args.theme
    else:
        # Look for theme in package
        theme_dir = os.path.join(os.path.dirname(__file__), 'themes')
        theme_path = os.path.join(theme_dir, f"{args.theme}.json")
    
    if not os.path.exists(theme_path):
        print(f"Error: Theme not found: {theme_path}", file=sys.stderr)
        return 1
    
    # Get grammar directory
    grammar_dir = os.path.join(os.path.dirname(__file__), 'grammars')
    
    # Create colorizer
    try:
        colorizer = Colorize(grammar_dir=grammar_dir, theme_path=theme_path)
    except Exception as e:
        print(f"Error loading colorizer: {e}", file=sys.stderr)
        return 1
    
    # Render and output
    try:
        colorized = colorizer.render(text, language)
        ansi_output = render_to_ansi(colorized, colors=args.colors)
        print(ansi_output)
    except Exception as e:
        print(f"Error highlighting: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
