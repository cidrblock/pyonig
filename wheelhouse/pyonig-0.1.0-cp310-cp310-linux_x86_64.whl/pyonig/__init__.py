"""Pyonig - Self-contained oniguruma regex engine for Python."""

from __future__ import annotations

__version__ = "0.1.0"

# Re-export main API from C extension
from pyonig._pyonig import (
    OnigError,
    compile,
    compile_regset,
    ONIG_OPTION_NONE,
    ONIG_OPTION_NOT_BEGIN_STRING,
    ONIG_OPTION_NOT_BEGIN_POSITION,
    ONIG_OPTION_NOT_END_STRING,
    __onig_version__,
)

__all__ = [
    "OnigError",
    "compile",
    "compile_regset",
    "ONIG_OPTION_NONE",
    "ONIG_OPTION_NOT_BEGIN_STRING",
    "ONIG_OPTION_NOT_BEGIN_POSITION",
    "ONIG_OPTION_NOT_END_STRING",
    "__onig_version__",
    "__version__",
]

